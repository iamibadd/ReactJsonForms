import { fetchEventLogs } from "./eventLogs.utils";
import {EventLogMetadata} from "./eventLogs.types";

const eventLogsList: EventLogMetadata[] = [] as EventLogMetadata[];

export default eventLogsList